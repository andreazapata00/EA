import { ITodo, TodoModel } from "../models/Todo.js";

// Crear
export async function createTodo(todo: Partial<ITodo>): Promise<ITodo | null> {
  const newTodo = new TodoModel(todo);
  return await newTodo.save();
}

// Leer por ID
export async function getTodoById(id: string): Promise<ITodo | null> {
  return await TodoModel.findById(id);
}

// Leer por código
export async function getTodoByCode(code: number): Promise<ITodo | null> {
  return await TodoModel.findOne({ code });
}

// Editar
export async function updateTodo(id: string, updates: Partial<ITodo>): Promise<ITodo | null> {
  return await TodoModel.findByIdAndUpdate(id, { $set: updates }, { new: true });
}

// Borrar
export async function deleteTodo(id: string): Promise<ITodo | null> {
  return await TodoModel.findByIdAndDelete(id);
}

// Listar
export async function listTodos(): Promise<ITodo[]> {
  return await TodoModel.find();
}
