import { TodoModel } from "../models/Todo.js";

export async function totalTodosCompletedByUser() {
  return await TodoModel.aggregate([
    { $match: { completed: true } },        // filtra completados
    { $group: { _id: "$user", total: { $sum: 1 } } }, // agrupa por usuario
    { $sort: { total: -1 } }               // ordena descendente
  ]);
}
